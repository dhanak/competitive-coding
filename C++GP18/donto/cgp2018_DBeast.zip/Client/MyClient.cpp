#include "stdafx.h"
#include "Client.h"
#include "parser.h"

// sample

class MYCLIENT : public CLIENT
{
public:
	MYCLIENT();
protected:
	virtual void Process();
	virtual void MatchEnd() {}

	void ThinkHero(HERO_INFO& hero);
	bool ThinkHeroTurret(HERO_INFO& hero);
	bool ThinkHeroEnemyHero(HERO_INFO& hero);
	bool ThinkHeroItem(HERO_INFO& hero);
	bool ThinkHeroNearestItem(HERO_INFO& hero);
	bool ThinkHeroGroup(HERO_INFO& hero);
	bool ThinkHeroDrop(HERO_INFO& hero);
	bool ThinkHeal(HERO_INFO& hero);
	bool ThinkAvoidEnemy(HERO_INFO& hero);

	TURRET_INFO* GetBestTurret(HERO_INFO& hero);
	TURRET_INFO* GetMainTurret(HERO_INFO& hero);
	double GetEffectiveHp(HERO_INFO& hero);
	double GetHeroPower(HERO_INFO& hero);
	double GetItemValue(HERO_INFO& hero, ITEM_INFO& item);
	bool NeedHealth(HERO_INFO& hero) { return hero.hp <= 50; }
	double GetArmyPowerDiff(POS pos); // mennyivel vagyunk erosebbek, negativ->gyengek vagyunk
};

MYCLIENT::MYCLIENT()
{
	strPassword = "UC9dXg";
	strAccount = "1";
	std::cout << "Healing" << std::endl;
}


TURRET_INFO* MYCLIENT::GetMainTurret(HERO_INFO& hero)
{
	if (mParser.Turrets[1].side == 2)
		return &mParser.Turrets[1];
	else
		return &mParser.Turrets[hero.id % mParser.Turrets.size()];
}

double MYCLIENT::GetArmyPowerDiff(POS pos)
{
	double enemyPower = 0;
	double ourPower = 0;
	for (auto &hero : mParser.Heroes)
	{
		int dist = hero.pos.DistSquare(pos);
		if (dist > HERO_ARMY_RANGE_SQ)
			continue;
		if (hero.side == 0)
			ourPower += GetHeroPower(hero) * (HERO_ARMY_RANGE_SQ - dist);
		else
			enemyPower += GetHeroPower(hero) * (HERO_ARMY_RANGE_SQ - dist);
	}
	return ourPower - enemyPower;
}

TURRET_INFO* MYCLIENT::GetBestTurret(HERO_INFO& hero)
{
	TURRET_INFO* main = GetMainTurret(hero);
	if (main->side != 0)
		return main;

	int minDist = 0;
	TURRET_INFO* best = nullptr;
	for (auto &turret : mParser.Turrets)
	{
		if (turret.side == 0)
			continue;
		int dist = mDistCache.GetDist(hero.pos, turret.pos);
		if (!best || dist < minDist)
		{
			minDist = dist;
			best = &turret;
		}
	}
	return best;
}

double MYCLIENT::GetEffectiveHp(HERO_INFO& hero)
{
	double eff = hero.hp;
	switch (hero.held_item)
	{
	case ITEM_INFO::eItemType::NO_ITEM: break;
	case ITEM_INFO::eItemType::ARMOR: eff *= 1.66; break;
	case ITEM_INFO::eItemType::CROSSBOW: eff *= 0.5; break;
	}
	return eff;
}
double MYCLIENT::GetHeroPower(HERO_INFO& hero)
{
	double power = hero.hp;
	switch (hero.held_item)
	{
	case ITEM_INFO::eItemType::NO_ITEM: break;
	case ITEM_INFO::eItemType::ARMOR: power *= 2.2; break;
	case ITEM_INFO::eItemType::CROSSBOW: power *= 2.0; break;
	case ITEM_INFO::eItemType::BOMB: power += 60; break;
	}
	return power;
}
bool MYCLIENT::ThinkHeroTurret(HERO_INFO& hero)
{
	TURRET_INFO* turret = GetBestTurret(hero);
	if (!turret)
		return false;

	if (hero.pos.DistSquare(turret->pos) <= HERO_RANGE_SQ)
	{
		Attack(hero.id, turret->id);
		return true;
	}
	Move(hero.id, mDistCache.GetNextTowards(hero.pos, turret->pos));
	return true;
}

bool MYCLIENT::ThinkHeroEnemyHero(HERO_INFO& hero)
{
	double minHp = 0;
	HERO_INFO* target = nullptr;

	for (auto &enemy : mParser.Heroes)
	{
		if (enemy.side == 0
			|| enemy.hp == 0)
			continue;
		int dist = hero.pos.DistSquare(enemy.pos);
		if (dist <= HERO_RANGE_SQ)
		{
			double effHp = GetEffectiveHp(enemy);
			if (!target || effHp < minHp)
			{
				target = &enemy;
				minHp = effHp;
			}
		}
	}
	if (target)
	{
		if (hero.held_item == ITEM_INFO::BOMB)
		{
			int numSamePos = 0;
			for (auto &enemy : mParser.Heroes)
			{
				if (enemy.side == 0
					|| enemy.hp == 0)
					continue;
				if (target->pos.DistSquare(enemy.pos) <= 2)
					numSamePos++;
			}
			if (hero.hp <= 30 || numSamePos >= 2)
			{
				Blast(hero.id, target->id);
				return true;
			}
		}
		Attack(hero.id, target->id);
		return true;
	}
	return false;
}

bool MYCLIENT::ThinkAvoidEnemy(HERO_INFO& hero)
{
	double diff = GetArmyPowerDiff(hero.pos);
	if (diff >= 0)
		return false;

	double str = diff;
	POS minPos = hero.pos;
	for(int dx = -1; dx <= 1; ++dx)
		for (int dy = -1; dy <= 1; ++dy)
		{
			POS p(hero.pos.x+dx, hero.pos.y +dy);
			if (!mParser.IsFree(p))
				continue;
			double s = GetArmyPowerDiff(p);
			if (s > str)
			{
				minPos = p;
				str = s;
			}
		}

	if (minPos != hero.pos)
	{
		Move(hero.id, minPos);
		return true;
	}
	return false;
}

bool MYCLIENT::ThinkHeroGroup(HERO_INFO& hero)
{
	if (hero.held_item != ITEM_INFO::NO_ITEM)
		return false;
	HERO_INFO* target = nullptr;
	int minDist = 0;
	for (auto &ally : mParser.Heroes)
	{
		if (ally.side != 0
			|| ally.held_item == ITEM_INFO::NO_ITEM)
			continue;
		int dist = mDistCache.GetDist(hero.pos, ally.pos);
		if (!target || dist < minDist)
		{
			dist = minDist;
			target = &ally;
		}
	}
	if (target && target->pos != hero.pos)
	{
		Move(hero.id, mDistCache.GetNextTowards(hero.pos, target->pos));
		return true;
	}
	return false;
}

double MYCLIENT::GetItemValue(HERO_INFO& hero, ITEM_INFO& item)
{
	double value = mDistCache.GetDist(hero.pos, item.pos);
	switch (item.t)
	{
	case ITEM_INFO::CROSSBOW: value *= 0.3; break;
	case ITEM_INFO::ARMOR: value *= 0.2; break;
	case ITEM_INFO::POTION: value *= 0.75; break;
	case ITEM_INFO::BOMB: value *= 2.0; break;
	}
	return value;
}

bool MYCLIENT::ThinkHeroNearestItem(HERO_INFO& hero)
{
	if (hero.held_item != ITEM_INFO::eItemType::NO_ITEM)
		return false; // van nalunk valami
	for (ITEM_INFO &item : mParser.Items)
	{
		if (NeedHealth(hero))
		{
			if (item.t != ITEM_INFO::POTION)
				continue;
		}
		else
		{
			if (item.t == ITEM_INFO::HAMMER
				|| item.t == ITEM_INFO::POTION)
				continue;
		}
		int dist = mDistCache.GetDist(hero.pos, item.pos);
		if (dist == 0)
		{
			GrabItem(hero.id);
			return true;
		}
		if (dist <= 2)
		{
			item.pickup = hero.id;
			Move(hero.id, mDistCache.GetNextTowards(hero.pos, item.pos));
			return true;
		}
	}
	return false;
}
bool MYCLIENT::ThinkHeroItem(HERO_INFO& hero)
{
	if (!NeedHealth(hero) && hero.held_item != ITEM_INFO::eItemType::NO_ITEM)
		return false; // van nalunk valami

	double min = 0;
	ITEM_INFO* minItem = nullptr;
	for (ITEM_INFO &item : mParser.Items)
	{
		if (item.pickup != -1)
			continue; // mar megy erte valaki
		if (NeedHealth(hero))
		{
			if (item.t != ITEM_INFO::POTION)
				continue;
		}
		else
		{
			if (item.t == ITEM_INFO::HAMMER
				|| item.t == ITEM_INFO::POTION
				|| item.t == ITEM_INFO::BOMB
				)
				continue;
		}
		double value = GetItemValue(hero, item);
		if (!minItem || value < min)
		{
			min = value;
			minItem = &item;
		}
	}
	if (!minItem)
		return false;
	minItem->pickup = hero.id;
	int dist = mDistCache.GetDist(hero.pos, minItem->pos);
	if (hero.held_item != ITEM_INFO::eItemType::NO_ITEM
		&& minItem->t == ITEM_INFO::POTION
		&& dist > 0
		&& dist <= 1)
	{
		DropItem(hero.id);
		return true;
	}
	if (minItem->pos == hero.pos)
	{
		GrabItem(hero.id);
		return true;
	}
	POS nextPos = mDistCache.GetNextTowards(hero.pos, minItem->pos);
	if (dist <= 2)
	{
		for (ITEM_INFO &item : mParser.Items)
		{
			if (item.pos == nextPos) // foglalt
			{
				DropItem(hero.id);
				return true;
			}
		}
	}
	Move(hero.id, nextPos);
	return true;
}

bool MYCLIENT::ThinkHeroDrop(HERO_INFO& hero)
{
	if (!NeedHealth(hero))
		return false;
	if (hero.held_item == ITEM_INFO::eItemType::NO_ITEM)
		return false;
	for (auto &checkHero : mParser.Heroes)
	{
		if (checkHero.side != 0
			|| checkHero.held_item != ITEM_INFO::eItemType::NO_ITEM
			|| NeedHealth(checkHero) )
			continue;
		int dist = mDistCache.GetDist(hero.pos, checkHero.pos);
		if (dist <= 2)
		{
			DropItem(hero.id);
			return true;
		}
	}
	return false;
}

bool MYCLIENT::ThinkHeal(HERO_INFO& hero)
{
	if (hero.held_item != ITEM_INFO::POTION)
		return false;

	for (auto &ally : mParser.Heroes)
	{
		if (ally.side != 0 || !NeedHealth(ally))
			continue;
		if (hero.pos.DistSquare(ally.pos) <= HERO_RANGE_SQ)
		{
			Heal(hero.id, ally.id);
			return true;
		}
	}
	return false;
}

void MYCLIENT::ThinkHero(HERO_INFO& hero)
{
	if (ThinkHeal(hero))
		return;
	if (ThinkHeroNearestItem(hero))
		return;
	if (ThinkHeroEnemyHero(hero))
		return;

	if (ThinkAvoidEnemy(hero))
		return;

	if (ThinkHeroItem(hero))
		return;
	if (ThinkHeroGroup(hero))
		return;
	if (ThinkHeroDrop(hero))
		return;
//	if (ThinkAvoidEnemy(hero))
//		return;
	if (ThinkHeroTurret(hero))
		return;
	Move(hero.id, mDistCache.GetNextTowards(hero.pos, GetMainTurret(hero)->pos ));
}

void MYCLIENT::Process()
{
	for (auto &hero : mParser.Heroes)
	{
		if (hero.controller_id == 0)
		{
			if (hero.hp == 0)
				continue; // respawning
			ThinkHero(hero);
		}
	}
}


CLIENT *CreateClient()
{
	return new MYCLIENT();
}
